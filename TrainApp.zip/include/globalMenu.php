<nav>
    <ul>
        <li><a href="calendar.php" class="icon fa-calendar"><span class="label">Calendario</span></a></li>
        <li><a href="graphics.php" class="icon fa-area-chart"><span class="label">Gráficos</span></a></li>
        <li><a href="stats.php" class="icon fa-newspaper-o"><span class="label">Historial</span></a></li>
        <li><a href="functions/logout.php" class="icon fa-power-off"><span class="label">Cerrar sesión</span></a></li>
    </ul>
</nav>