<head>
        <title>Historial de <?php echo $user; ?></title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->

        <!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
        <!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
        <!-- usuarios.php -->
        <link href="calendar/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="innerAssets/css/main.css" />
        <link rel="stylesheet" href="innerAssets/css/graficos.css">
        <link rel="javascript" href="js/bootstrap.min.js">
        <style>
            body {
                padding-top: 70px;
                /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
            }
            #calendar {
                    max-width: 800px;
            }
            .col-centered{
                    float: none;
                    margin: 0 auto;
            }
        </style>

</head>