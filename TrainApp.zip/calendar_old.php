<html>
    <?php include 'calendarHead.php'; ?>
    <body>
        <div class="container">
        <div id="calendar"></div>
        </div>
        <?php include 'include/calendarModal.php'; ?>
    </body>
    <?php include 'include/calendarScript.php'; ?>
</html>
