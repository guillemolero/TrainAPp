<?php
session_start();

    include "functions/login.php";
    
?>
<html>
    <?php include 'include/indexHead.php'; ?>
    <?php include 'include/indexBody.php'; ?>
</html>