<?php

session_start();

$user = $_SESSION['user'];
